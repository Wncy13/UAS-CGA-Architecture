using UnityEngine;
using UnityEngine.UI;

public class ButtonSwitcher : MonoBehaviour
{
    public Transform buildPanel; // Reference to BuildPanel
    public Transform inventoryManager; // Reference to InventoryManager

    // Function to swap buttons
    public void SwapButtons(GameObject clickedButton)
    {
        if (clickedButton == null)
        {
            Debug.LogError("clickedButton is null. Please ensure the correct object is passed.");
            return;
        }

        // Ensure the clicked object has a Button component
        Button button = clickedButton.GetComponent<Button>();
        if (button == null)
        {
            Debug.LogError($"The clicked object ({clickedButton.name}) does not have a Button component.");
            return;
        }

        // Determine the parent panel and move the button
        Transform parent = button.transform.parent;

        if (parent == inventoryManager)
        {
            button.transform.SetParent(buildPanel);
            Debug.Log($"Moved {clickedButton.name} to BuildPanel.");
        }
        else if (parent == buildPanel)
        {
            button.transform.SetParent(inventoryManager);
            Debug.Log($"Moved {clickedButton.name} to InventoryManager.");
        }
        else
        {
            Debug.LogError("The button is not in either the InventoryManager or BuildPanel.");
        }
    }

    // Called when a button is clicked
public void OnClick()
{
    GameObject clickedButton = UnityEngine.EventSystems.EventSystem.current.currentSelectedGameObject;
    if (clickedButton == null)
    {
        Debug.LogError("No button clicked.");
        return;
    }

    Debug.Log($"Button clicked: {clickedButton.name}");
    SwapButtons(clickedButton);
}

}
