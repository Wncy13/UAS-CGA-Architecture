using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public Camera playerCamera; // Kamera utama
    public Camera buildCamera; // Kamera untuk Build Mode
    public GameObject Panel; // UI Panel untuk Build State
    public Button buildButton; // Tombol Build di layar utama
    public Button saveButton; // Tombol Save di Build State
    public Button backButton; // Tombol Back di Build State

    private bool isBuilding = false;

    public float mouseSensitivity = 100f; // Sensitivitas gerakan mouse
    public float movementSpeed = 10f; // Kecepatan gerakan kamera

    void Start()
    {
        // Menonaktifkan semua elemen UI selain BuildButton
        Panel.SetActive(false);
        saveButton.gameObject.SetActive(false);
        backButton.gameObject.SetActive(false);
        buildCamera.gameObject.SetActive(false);

        // Menambahkan listener untuk tombol
        buildButton.onClick.AddListener(StartBuildMode);
        saveButton.onClick.AddListener(SavePlacement);
        backButton.onClick.AddListener(EndBuildMode);

        // Memastikan game dimulai dalam mode Main Camera
        EndBuildMode();
    }

    void StartBuildMode()
    {
        isBuilding = true;

        // Alihkan ke Build Camera
        playerCamera.gameObject.SetActive(false);
        buildCamera.gameObject.SetActive(true);

        // Tampilkan elemen Build Mode
        Panel.SetActive(true);
        buildButton.gameObject.SetActive(false);
        saveButton.gameObject.SetActive(true);
        backButton.gameObject.SetActive(true);

        // Bebaskan kursor untuk interaksi UI
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    void EndBuildMode()
    {
        isBuilding = false;

        // Alihkan ke Main Camera
        buildCamera.gameObject.SetActive(false);
        playerCamera.gameObject.SetActive(true);

        // Sembunyikan elemen Build Mode dan tampilkan hanya BuildButton
        Panel.SetActive(false);
        saveButton.gameObject.SetActive(false);
        backButton.gameObject.SetActive(false);
        buildButton.gameObject.SetActive(true);

        // Kunci kembali kursor untuk kontrol kamera
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void SavePlacement()
    {
        // Implementasi penyimpanan penempatan objek
        Debug.Log("Placement saved.");
    }

    void Update()
    {
        // Kontrol kamera hanya saat tidak dalam mode build
        if (!isBuilding)
        {
            HandleCameraMovement();
        }
    }

    void HandleCameraMovement()
    {
        // Pergerakan kamera di sumbu X (maju mundur)
        float moveDirection = Input.GetAxis("Vertical") * movementSpeed * Time.deltaTime;

        // Menggerakkan kamera dengan menggunakan input W dan S
        Vector3 movement = playerCamera.transform.forward * moveDirection;
        movement.y = 0; // Menghilangkan pergerakan di sumbu Y

        playerCamera.transform.position += movement; // Menggerakkan kamera
    }
}